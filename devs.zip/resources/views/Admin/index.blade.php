@extends('adminlte::page')

@section('title', 'Painel principal')

@section('content_header')
    <h1>Painel de Controle</h1>
@endsection
