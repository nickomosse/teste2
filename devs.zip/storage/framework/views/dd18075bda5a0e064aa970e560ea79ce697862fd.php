<?php $__env->startSection('title', "Serviço"); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Serviço</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="card">
        <div class="card-body">
            <ul>
                <li>
                    <strong>Id: </strong> <?php echo e($service->id); ?>

                </li>
                <li>
                    <strong>Nome do Serviço: </strong> <?php echo e($service->name); ?>

                </li>
                <li>
                    <strong>Nome do dono do Serviço: </strong> <?php echo e($service->providerName); ?>

                </li>
                <li>
                    <strong>Telefone do dono do Serviço: </strong> <?php echo e($service->providerPhone); ?>

                </li>
                <li>
                    <strong>Nome da casa indicadora: </strong> <?php echo e($service->user->companyName); ?>

                </li>
                <li>
                    <strong>Nome do Representante: </strong> <?php echo e($service->user->name); ?>

                </li>
                <li>
                    <strong>Tipo do serviço: </strong> <?php echo e($service->serviceType->name); ?>

                </li>

            </ul>

            <form action="<?php echo e(route('services.destroy', $service->id)); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <?php echo method_field('DELETE'); ?>
                <button type="submit" class="btn btn-danger"><i class="fas fa-trash"></i>DELETAR</button>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\devs\resources\views/admin/services/show.blade.php ENDPATH**/ ?>