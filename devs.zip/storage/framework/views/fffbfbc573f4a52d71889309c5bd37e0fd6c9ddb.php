<?php $__env->startSection('title', "serviço"); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Novo serviço</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="card">
        <div class="card-body">
            <form action="<?php echo e(route('services.store')); ?>" class="form" method="POST">
                <?php echo csrf_field(); ?>

                <div class="form-group">
                    <label>Nome do serviço:</label>
                    <input type="text" name="name" class="form-control" placeholder="Marcos refrigeração">
                </div>

                <div class="form-group">
                    <label>Nome do Dono:</label>
                    <input type="text" name="providerName" class="form-control" placeholder="Marcos Cruz">
                </div>

                <div class="form-group">
                    <label>Telefone do dono:</label>
                    <input type="text" name="providerPhone" class="form-control" placeholder="21999999999">
                </div>

                <div class="form-group">
                    <label for="serviceType_id">Tipo de serviço:</label>
                    <select class="custom-select rounded-0" id="serviceType_id" name="serviceType_id">
                        <?php $__currentLoopData = $serviceTypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $serviceType): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($serviceType->id); ?>"><?php echo e($serviceType->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>

                <div class="form-group">
                    <label for="user_id">Casa recomendadora:</label>
                    <select class="custom-select rounded-0" id="user_id" name="user_id">
                        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($user->id); ?>"><?php echo e($user->companyName); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>

                <div class="form-group">
                    <button type="submit" class="btn btn-dark">Salvar</button>
                </div>
            </form>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\devs\resources\views/admin/services/create.blade.php ENDPATH**/ ?>