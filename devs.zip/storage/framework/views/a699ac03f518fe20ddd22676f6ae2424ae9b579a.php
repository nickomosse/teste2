<?php $__env->startSection('title', 'Painel principal'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Painel de Controle</h1>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\devs\resources\views/admin/index.blade.php ENDPATH**/ ?>