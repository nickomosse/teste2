<?php $__env->startSection('title', "Serviço"); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Serviço</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="card">
        <div class="card-body">
            <form action="<?php echo e(route('services.update', $service->id)); ?>" class="form" method="POST">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>

                <div class="form-group">
                    <label>Nome:</label>
                    <input type="text" name="name" class="form-control" placeholder="Marcos refrigeração" value="<?php echo e($service->name ?? old('name')); ?>">
                </div>

                <div class="form-group">
                    <label>Nome do Dono:</label>
                    <input type="text" name="providerName" class="form-control" placeholder="Marcos Cruz" value="<?php echo e($service->providerName ?? old('providerName')); ?>">
                </div>

                <div class="form-group">
                    <label>Telefone do dono:</label>
                    <input type="text" name="providerPhone" class="form-control" placeholder="21999999999" value="<?php echo e($service->providerPhone ?? old('providerPhone')); ?>">
                </div>

                <div class="form-group">
                    <label for="serviceType_id">Tipo de serviço:</label>
                    <select class="custom-select rounded-0" id="serviceType_id" name="serviceType_id">
                        <?php $__currentLoopData = $serviceTypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $serviceType): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option <?php if($service->serviceType_id == $serviceType->id): ?> selected <?php endif; ?> value="<?php echo e($serviceType->id); ?>"><?php echo e($serviceType->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>

                <div class="form-group">
                    <label for="user_id">Casa recomendadora:</label>
                    <select class="custom-select rounded-0" id="user_id" name="user_id">
                        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option <?php if($service->user_id == $user->id): ?> selected <?php endif; ?> value="<?php echo e($user->id); ?>"><?php echo e($user->companyName); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>

                <div class="form-group">
                    <button type="submit" class="btn btn-dark">Salvar</button>
                </div>
            </form>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\devs\resources\views/admin/services/edit.blade.php ENDPATH**/ ?>