<?php $__env->startSection('title', 'Serviço'); ?>

<?php $__env->startSection('content_header'); ?>
    <ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="">Dashboard</a></li>
        <li class="breadcrumb-item active"><a href="" class="active">Serviço</a></li>
    </ol>

    <h1>Serviço <a href="<?php echo e(route('services.create')); ?>" class="btn btn-dark">Adicionar</a></h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="card">
        <div class="card-body">
            <table class="table table-condensed">
                <thead>
                    <tr>
                        <th>Id</th>
                        <th>Nome</th>
                        <th width="270">Ações</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td>
                                <?php echo e($service->id); ?>

                            </td>
                            <td>
                                <?php echo e($service->name); ?>

                            </td>
                            <td style="width=10px;">
                                <a href="<?php echo e(route('services.edit', $service->id)); ?>" class="btn btn-info">Editar</a>
                                <a href="<?php echo e(route('services.show', $service->id)); ?>" class="btn btn-warning">Ver</a>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\devs\resources\views/admin/services/index.blade.php ENDPATH**/ ?>