<h1>Teste</h1>

<p>Testando email! Nome: {{ $user->name }}</p>
