<h1>Recuperação de senha</h1>

<p>O seu código é: {{$code}}</p>
